////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class MailTemplates extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10">
                <section className="d-flex align-items-center justify-content-between p-3">
                  <span>All email templates</span>
                </section>
              </section>
            </section>

            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 pr-2 pl-2">
                <section className="p-2 table-ad-pricing">
                  <table>
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Topic</th>
                        <th>See</th>
                        <th>Edit</th>
                      </tr>
                    </thead>

                    <tbody>
                      <tr>
                        <td>1</td>
                        <td>New user registration (user)</td>
                        <td>
                          <span className="bg-info input-buttons pt-1 pb-1 pr-1 pl-1">
                            See
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Edit
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td>New user registration (admin)</td>
                        <td>
                          <span className="bg-info input-buttons pt-1 pb-1 pr-1 pl-1">
                            See
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Edit
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td>New user registration (user)</td>
                        <td>
                          <span className="bg-info input-buttons pt-1 pb-1 pr-1 pl-1">
                            See
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Edit
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
