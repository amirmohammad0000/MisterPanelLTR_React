////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class HomePageTemplate extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10">
                <section className="col-12 p-3">
                  <h2>Change the homepage format</h2>
                  <span>
                    Now you can easily change your home page theme and Attract
                    more customers and Google rankings.
                  </span>
                </section>

                <section className="col-12 p-3">
                  <p>Sorry</p>
                  <span>
                    In this section, your website templates should be displayed
                    and because The fact that this admin panel is not connected
                    to the database and to a website is not a template This
                    section is not displayed and this section remains empty
                  </span>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
