////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class CreateNewInvoice extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10">
                <section className="col-12 p-3">
                  <span>Invoice - Premium workers</span>
                </section>

                <section className="col-12 p-3">
                  <textarea
                    className="input-content-users p-2"
                    rows="15"
                    defaultValue={`You are a golden member of Your 1 Mistar World Business Panel website.

Worker: Amir Mohammad Koshkian

Bridge type: Premium

Amount paid: $250

Email: koshkian1000@gmail.com

Payment type: Cash payment upon delivery

ProFile: https://amirmohammad0.ir

Address : American Florida Florida

You are a golden member of Your 1 Mistar World Business Panel website.`}
                  ></textarea>
                </section>

                <section className="col-12 p-3 d-flex align-items-center justify-content-center">
                  <a
                    href="/public/Assets/Images/Logo.png"
                    download={true}
                    className="input-content-users p-2 bg-danger d-flex align-items-center justify-content-center"
                  >
                    Download pdf
                  </a>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
