////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewProduct extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <form method="POST" encType="multipart/form-data">
                  <section className="col-12">
                    <section className="col-12 p-2">
                      <span>Add New Product</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="SelectUser"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="amir mohammad">Amir Mohammad</option>
                        <option value="amir ali">Amir Ali</option>
                        <option value="ali reza">Alireza</option>
                        <option value="mohammad">Mohammad</option>
                        <option value="hossein">Hossein</option>
                      </select>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>name Product</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="ProductName"
                          type="text"
                          placeholder="name Product"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Selection is the category</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="SelectCategory"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="Health">sports</option>
                          <option value="Toys">toy</option>
                        </select>
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Under Grouping is Selection</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="SelectSubCategory"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="Toys">toy</option>
                          <option value="Health">sports</option>
                        </select>
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Price</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Price"
                          type="text"
                          placeholder="Price"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-12">
                      <section className="col-12 p-2">
                        <span>before institution</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Offer"
                          placeholder="before institution"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>External link payment product</span>
                      </section>

                      <section className="col-12">
                        <textarea
                          name="ProductPaymentExternalLink"
                          className="input-content-users p-2"
                          placeholder="External link payment product"
                          required={true}
                        ></textarea>
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Product specifications</span>
                      </section>

                      <section className="col-12">
                        <textarea
                          name="ProductDetails"
                          placeholder="Product specifications"
                          className="input-content-users p-2"
                          required={true}
                        ></textarea>
                      </section>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Product pictures (up to 5 pictures)</span>
                    </section>

                    <section className="col-12">
                      <input
                        name="ProductImages"
                        type="file"
                        className="input-content-users p-2"
                        required={true}
                      ></input>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>
                        Product Tags (i.e.) Electronics, Laptop, HP, Canon
                      </span>
                    </section>

                    <section className="col-12">
                      <textarea
                        name="ProductTags"
                        placeholder="Product Tags (i.e.) Electronics, Laptop, HP, Canon"
                        className="input-content-users p-2"
                        required={true}
                      ></textarea>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12">
                      <input
                        type="submit"
                        name="SubmitAddNewJob"
                        value="Submit"
                        className="input-content-users p-2 bg-info"
                      />
                    </section>
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
