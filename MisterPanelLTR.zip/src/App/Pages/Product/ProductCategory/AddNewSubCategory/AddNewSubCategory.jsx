////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewSubCategory extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-xl-12 text-center">
                  <span>Adding the Product New subcategory</span>
                </section>

                <form method="POST">
                  <section className="col-xl-12 pt-4">
                    <select
                      className="input-content-users p-2"
                      name="ListingName"
                      required={true}
                    >
                      <option value="SelectListingName">
                        Select Directory name
                      </option>
                      <option value="Css">Css</option>
                      <option value="Html">HTML</option>
                      <option value="JavaScript">Java Script</option>
                      <option value="Php">PHP</option>
                      <option value="Sql">SQL</option>
                    </select>
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      name="SubCategoryName"
                      placeholder="Subgroup name"
                      required={true}
                    />
                  </section>

                  <section className="d-flex col-xl-12 pt-5">
                    <input
                      type="submit"
                      className="input-content-users p-2 bg-success"
                      name="SendListingSubCategory"
                      value="Submit"
                      required={true}
                    />
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
