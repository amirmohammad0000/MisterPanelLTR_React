////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
import {
  KeyboardArrowUp,
  AttachMoney,
  Link,
  CalendarMonth,
  PersonOutlineOutlined,
  Poll,
  TrendingUp,
  Star,
  KeyboardArrowDown,
} from "@mui/icons-material";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class Widgets extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-12 p-2">
              <section className="d-flex">
                <section className="col-xl-6 d-flex">
                  <section className="col-xl-6 p-2 mb-1">
                    <section className="bg-t-o b-r-10">
                      <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                        <section>
                          <AttachMoney className="text-color-main" />
                        </section>

                        <section>
                          <KeyboardArrowUp className="text-success" />

                          <span className="text-success">75.2K</span>
                        </section>
                      </section>

                      <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-1 pl-1 pb-2">
                        <span>Total income</span>
                      </section>

                      <section className="col-sm-12 pr-1 pl-1 pb-3 pt-4 pb-4">
                        <section className="d-flex align-items-start justify-content-between">
                          <span>Percentage of income</span>
                          <span>75</span>
                        </section>
                        <section className="progress">
                          <section
                            aria-valuemax="100"
                            aria-valuemin="0"
                            aria-valuenow="20"
                            className="progress-bar progress-bar-xs wd-75p"
                            role="progressbar"
                          ></section>
                        </section>
                      </section>
                    </section>
                  </section>

                  <section className="col-xl-6 p-2">
                    <section className="bg-t-o b-r-10">
                      <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                        <section>
                          <Link className="text-color-main" />
                        </section>

                        <section>
                          <KeyboardArrowUp className="text-success" />

                          <span className="text-success">64.4%+</span>
                        </section>
                      </section>

                      <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-2">
                        <span className="pb-1">142.8 Thousand</span>
                        <span>Total withdrawals</span>
                      </section>

                      <section className="col-sm-12 d-flex align-items-start justify-content-start pr-1 pb-3 pt-4">
                        <span className="bg-t-d-m b-r-10 pr-1 pl-1">
                          A year past
                        </span>
                      </section>
                    </section>
                  </section>
                </section>

                <section className="col-xl-6 d-flex">
                  <section className="col-xl-6 p-2 mb-1">
                    <section className="bg-t-o b-r-10">
                      <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                        <section>
                          <Link className="text-color-main" />
                        </section>

                        <section>
                          <KeyboardArrowUp className="text-success" />

                          <span className="text-success">83.4%+</span>
                        </section>
                      </section>

                      <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-2">
                        <span className="pb-1">54.8 Thousand</span>
                        <span>Total withdrawals</span>
                      </section>

                      <section className="col-sm-12 d-flex align-items-start justify-content-start pr-1 pb-3 pt-4">
                        <span className="bg-t-d-m b-r-10 pr-1 pl-1">
                          last two years
                        </span>
                      </section>
                    </section>
                  </section>

                  <section className="col-xl-6 p-2">
                    <section className="bg-t-o b-r-10">
                      <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                        <section>
                          <AttachMoney className="text-color-main" />
                        </section>

                        <section>
                          <KeyboardArrowUp className="text-success" />

                          <span className="text-success">6.2K</span>
                        </section>
                      </section>

                      <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-1 pl-1 pb-2">
                        <span>Total income</span>
                      </section>

                      <section className="col-sm-12 pr-1 pl-1 pb-3 pt-4 pb-4">
                        <section className="d-flex align-items-start justify-content-between">
                          <span>Percentage of income</span>
                          <span>45</span>
                        </section>
                        <section className="progress">
                          <section
                            aria-valuemax="100"
                            aria-valuemin="0"
                            aria-valuenow="20"
                            className="progress-bar progress-bar-xs bg-danger wd-45p"
                            role="progressbar"
                          ></section>
                        </section>
                      </section>
                    </section>
                  </section>
                </section>
              </section>

              <section className="row col-xl-12">
                <section className="col-xl-6 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="row p-3">
                      <h3>Sales overview</h3>

                      <span>A total of 42.5 thousand sales</span>
                    </section>

                    <section className="row d-flex align-items-start justify-content-start pr-2 pt-1 pb-3">
                      <section className="col-xl-4 d-flex align-items-center justify-content-start pt-2 pb-2">
                        <section className="col-xl-2 bg-success b-r-10 d-flex align-items-center justify-content-start p-2">
                          <PersonOutlineOutlined />
                        </section>

                        <section className="col-xl-10 d-flex flex-column pr-1">
                          <h4 className="m-0">8,524</h4>

                          <span>Customers</span>
                        </section>
                      </section>

                      <section className="col-xl-4 d-flex align-items-center justify-content-start pt-2 pb-2">
                        <section className="col-xl-2 bg-main b-r-10 d-flex align-items-center justify-content-start p-2">
                          <Poll />
                        </section>

                        <section className="col-xl-10 d-flex flex-column pr-1">
                          <h4 className="m-0">5000$</h4>

                          <span>Total profit</span>
                        </section>
                      </section>

                      <section className="col-xl-4 d-flex align-items-center justify-content-start pt-2 pb-2">
                        <section className="col-xl-2 bg-danger b-r-10 d-flex align-items-center justify-content-start p-2">
                          <TrendingUp />
                        </section>

                        <section className="col-xl-10 d-flex flex-column pr-1">
                          <h4 className="m-0">2,435k</h4>

                          <span>Trades</span>
                        </section>
                      </section>
                    </section>
                  </section>
                </section>

                <section className="col-xl-3 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="bg-t-o b-r-10">
                      <section className="p-3">
                        <h3 className="mb-4">Ratings</h3>

                        <span className="bg-main b-r-10 pr-1 pl-1 text-nowrap">
                          The year 2022
                        </span>
                      </section>

                      <section className="p-3">
                        <section className="col-sm-12 d-flex align-items-center justify-content-between p-2">
                          <section>
                            <Star className="text-color-main" />
                          </section>

                          <section>
                            <KeyboardArrowUp className="text-success" />

                            <span className="text-success">26%+</span>
                          </section>
                        </section>
                      </section>
                    </section>
                  </section>
                </section>

                <section className="col-xl-3 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="bg-t-o b-r-10">
                      <section className="p-3">
                        <h3 className="mb-4">meetings</h3>

                        <span className="bg-success b-r-10 pr-1 pl-1 text-nowrap">
                          Previous month
                        </span>
                      </section>

                      <section className="p-3">
                        <section className="col-sm-12 d-flex align-items-center justify-content-between p-2">
                          <section>
                            <CalendarMonth className="text-color-main" />
                          </section>

                          <section>
                            <KeyboardArrowDown className="text-danger" />

                            <span className="text-danger">72%+</span>
                          </section>
                        </section>
                      </section>
                    </section>
                  </section>
                </section>
              </section>

              <section className="row">
                <section className="col-xl-8 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="row p-4 pb-5">
                      <h3>Activity timeline</h3>
                    </section>

                    <section className="row pb-4 d-flex align-items-center justify-content-between">
                      <section className="col-9 position-relative">
                        <span className="span-point-right-activity-time-line-content-page-analytics bg-danger"></span>

                        <section className="d-flex flex-column pr-5">
                          <p>Make a video for Next product</p>

                          <span>Introduction video and product details</span>
                        </section>
                      </section>

                      <section className="col-3 d-flex align-items-center justify-content-center">
                        <span>Tomorrow</span>
                      </section>
                    </section>

                    <section className="row pb-4 d-flex align-items-center justify-content-between">
                      <section className="col-9 position-relative">
                        <span className="span-point-right-activity-time-line-content-page-analytics bg-primary"></span>

                        <section className="d-flex flex-column pr-5">
                          <p>A payment has been received from the customer</p>

                          <span>Received $100,000 for Android Banking App</span>
                        </section>
                      </section>

                      <section className="col-3 d-flex align-items-center justify-content-center">
                        <span>April 12</span>
                      </section>
                    </section>

                    <section className="row pb-4 d-flex align-items-center justify-content-between">
                      <section className="col-9 position-relative">
                        <span className="span-point-right-activity-time-line-content-page-analytics bg-success"></span>

                        <section className="d-flex flex-column pr-5">
                          <p>
                            Meeting with Amir Mohammad Koshkian for the Next
                            project
                          </p>

                          <span>Video call session at 9 pm</span>
                        </section>
                      </section>

                      <section className="col-3 d-flex align-items-center justify-content-center">
                        <span>May 21</span>
                      </section>
                    </section>
                  </section>
                </section>

                <section className="col-xl-4 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="bg-t-o b-r-10">
                      <section className="row pr-2 pt-3">
                        <section className="col-xl-12">
                          <h3>Project statistics</h3>
                        </section>
                      </section>

                      <section className="row pr-2 pl-2 pt-2">
                        <section className="col-xl-6 d-flex align-items-center justify-content-start">
                          <span>name</span>
                        </section>

                        <section className="col-xl-6 d-flex align-items-center justify-content-end">
                          <span>Budget</span>
                        </section>
                      </section>

                      <section className="row p-4">
                        <section className="d-flex d-flex align-items-center justify-content-between pb-2">
                          <section className="col-xl-10 d-flex align-items-center justify-content-start">
                            <img
                              alt="Project 1"
                              loading="lazy"
                              src="/Assets/Images/Project/Project1.png"
                              width="50px"
                              className="col-xl-1"
                            />

                            <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                              <span>Illustration of three Next</span>

                              <span>Blender program</span>
                            </section>
                          </section>

                          <section className="col-xl-2 d-flex align-center justify-content-center">
                            <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                              100$
                            </span>
                          </section>
                        </section>

                        <section className="d-flex d-flex align-items-center justify-content-between pb-2 pt-2">
                          <section className="col-xl-10 d-flex align-items-center justify-content-start">
                            <img
                              alt="Project 2"
                              loading="lazy"
                              src="/Assets/Images/Project/Project3.png"
                              width="50px"
                              className="col-xl-1"
                            />

                            <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                              <span>Whatsapp</span>

                              <span>Android app</span>
                            </section>
                          </section>

                          <section className="col-xl-2 d-flex align-center justify-content-center">
                            <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                              200$
                            </span>
                          </section>
                        </section>

                        <section className="d-flex d-flex align-items-center justify-content-between pb-2 pt-2">
                          <section className="col-xl-10 d-flex align-items-center justify-content-start">
                            <img
                              alt="Project 3"
                              loading="lazy"
                              src="/Assets/Images/Project/Project4.png"
                              width="50px"
                              className="col-xl-1"
                            />

                            <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                              <span>Web application</span>

                              <span>React</span>
                            </section>
                          </section>

                          <section className="col-xl-2 d-flex align-center justify-content-center">
                            <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                              160$
                            </span>
                          </section>
                        </section>

                        <section className="d-flex d-flex align-items-center justify-content-between pt-2">
                          <section className="col-xl-10 d-flex align-items-center justify-content-start">
                            <img
                              alt="Project 4"
                              loading="lazy"
                              src="/Assets/Images/Project/Project5.png"
                              width="50px"
                              className="col-xl-1"
                            />

                            <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                              <span>website</span>

                              <span>Vue + Laravel</span>
                            </section>
                          </section>

                          <section className="col-xl-2 d-flex align-center justify-content-center">
                            <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                              120$
                            </span>
                          </section>
                        </section>
                      </section>
                    </section>
                  </section>
                </section>
              </section>

              <section className="row">
                <section className="col-xl-4 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="row pr-2 pb-4 pt-3">
                      <h3>The most sales in countries</h3>
                    </section>

                    <section className="row d-flex pr-2 pb-3 flex-column">
                      <section className="d-flex align-items-start justify-content-start">
                        <h2 className="m-0 pl-3">222,546</h2>

                        <span className="bg-success b-r-10 p-1">42.5%+</span>
                      </section>

                      <span className="pt-2">Sales of the last 90 days</span>
                    </section>

                    <section className="row bt pt-2 pb-2 mr-4 ml-4">
                      <section className="col-6">
                        <span>Australia</span>
                      </section>

                      <section className="col-4">
                        <span>10,357</span>
                      </section>

                      <section className="col-2">
                        <span className="pl-1">85%</span>

                        <KeyboardArrowUp className="text-success" />
                      </section>
                    </section>

                    <section className="row bt pt-2 pb-2 mr-4 ml-4">
                      <section className="col-6">
                        <span>Canada</span>
                      </section>

                      <section className="col-4">
                        <span>16,937</span>
                      </section>

                      <section className="col-2">
                        <span className="pl-1">54%</span>

                        <KeyboardArrowDown className="text-danger" />
                      </section>
                    </section>

                    <section className="row bt pt-2 pb-2 mr-4 ml-4">
                      <section className="col-6">
                        <span>India</span>
                      </section>

                      <section className="col-4">
                        <span>43,473</span>
                      </section>

                      <section className="col-2">
                        <span className="pl-1">76%</span>

                        <KeyboardArrowUp className="text-success" />
                      </section>
                    </section>

                    <section className="row bt pt-2 pb-2 mr-4 ml-4">
                      <section className="col-6">
                        <span>Japan</span>
                      </section>

                      <section className="col-4">
                        <span>19,757</span>
                      </section>

                      <section className="col-2">
                        <span className="pl-1">42%</span>

                        <KeyboardArrowUp className="text-success" />
                      </section>
                    </section>

                    <section className="row bt pt-2 pb-2 mr-4 ml-4">
                      <section className="col-6">
                        <span>United States</span>
                      </section>

                      <section className="col-4">
                        <span>12,565</span>
                      </section>

                      <section className="col-2">
                        <span className="pl-1">84%</span>

                        <KeyboardArrowDown className="text-danger" />
                      </section>
                    </section>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
