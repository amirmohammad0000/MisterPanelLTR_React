////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class Buttons extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-12 p-2">
              <section className="col-12 p-2">
                <section className="p-2 bg-t-o b-r-10">
                  <section className="col-12">Bootstrap buttons</section>

                  <section className="d-flex">
                    <section className="col-2 p-3 d-flex align-items-center justify-content-center">
                      <button className="btn btn-primary w-100 h-100">
                        First
                      </button>
                    </section>

                    <section className="col-2 p-3 d-flex align-items-center justify-content-center">
                      <button className="btn btn-secondary w-100 h-100">
                        secondary
                      </button>
                    </section>

                    <section className="col-2 p-3 d-flex align-items-center justify-content-center">
                      <button className="btn btn-success w-100 h-100">
                        Success
                      </button>
                    </section>

                    <section className="col-2 p-3 d-flex align-items-center justify-content-center">
                      <button className="btn btn-info w-100 h-100">info</button>
                    </section>

                    <section className="col-2 p-3 d-flex align-items-center justify-content-center">
                      <button className="btn btn-warning w-100 h-100">
                        Warning
                      </button>
                    </section>

                    <section className="col-2 p-3 d-flex align-items-center justify-content-center">
                      <button className="btn btn-danger w-100 h-100">
                        Danger
                      </button>
                    </section>
                  </section>
                </section>
              </section>

              <section className="col-12 p-2">
                <section className="p-2 bg-t-o b-r-10">
                  <section className="col-12">Built-in input buttons</section>

                  <section className="d-flex">
                    <section className="col-2 p-3">
                      <input
                        className="input-content-users p-2 bg-primary"
                        type="button"
                        value="First"
                      />
                    </section>

                    <section className="col-2 p-3">
                      <input
                        className="input-content-users p-2 bg-secondary"
                        type="button"
                        value="secondary"
                      />
                    </section>

                    <section className="col-2 p-3">
                      <input
                        className="input-content-users p-2 bg-success"
                        type="button"
                        value="Success"
                      />
                    </section>

                    <section className="col-2 p-3">
                      <input
                        className="input-content-users p-2 bg-info"
                        type="button"
                        value="info"
                      />
                    </section>

                    <section className="col-2 p-3">
                      <input
                        className="input-content-users p-2 bg-warning"
                        type="button"
                        value="Warning"
                      />
                    </section>

                    <section className="col-2 p-3">
                      <input
                        className="input-content-users p-2 bg-danger"
                        type="button"
                        value="Danger"
                      />
                    </section>
                  </section>
                </section>
              </section>

              <section className="col-12 p-2">
                <section className="p-2 bg-t-o b-r-10">
                  <section className="col-12">
                    Personalized buttons for this template
                  </section>

                  <section className="d-flex">
                    <section className="col-2 p-3">
                      <span className="w-100 h-100 input-buttons pt-1 pb-1 pr-1 pl-1 bg-primary">
                        First
                      </span>
                    </section>

                    <section className="col-2 p-3">
                      <span className="w-100 h-100 input-buttons pt-1 pb-1 pr-1 pl-1 bg-secondary">
                        secondary
                      </span>
                    </section>

                    <section className="col-2 p-3">
                      <span className="w-100 h-100 input-buttons pt-1 pb-1 pr-1 pl-1 bg-success">
                        Success
                      </span>
                    </section>

                    <section className="col-2 p-3">
                      <span className="w-100 h-100 input-buttons pt-1 pb-1 pr-1 pl-1 bg-info">
                        info
                      </span>
                    </section>

                    <section className="col-2 p-3">
                      <span className="w-100 h-100 input-buttons pt-1 pb-1 pr-1 pl-1 bg-warning">
                        Warning
                      </span>
                    </section>

                    <section className="col-2 p-3">
                      <span className="w-100 h-100 input-buttons pt-1 pb-1 pr-1 pl-1 bg-danger">
                        Danger
                      </span>
                    </section>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
