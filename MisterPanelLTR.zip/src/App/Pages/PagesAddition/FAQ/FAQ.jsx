////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
import { Search, Call, MailOutline } from "@mui/icons-material";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class FAQ extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10">
                <section className="col-12 p-3 d-flex flex-column align-items-center justify-content-center">
                  <h2 className="pb-3">Hello, how can we help?</h2>

                  <span>
                    Or make a category Selection is to quickly get the help you
                    need Find is
                  </span>

                  <section className="col-xl-4 pt-4">
                    <form className="form-search" method="GET">
                      <input
                        placeholder="Ask questions ..."
                        className="input-form-search"
                        name="Search"
                        required
                      />

                      <button type="submit" className="button-form-search">
                        <Search titleAccess="Search for the desired word" />
                      </button>
                    </form>
                  </section>
                </section>
              </section>
            </section>

            <section className="row d-flex align-items-center justify-content-center">
              <section className="d-flex align-items-center justify-content-center p-2">
                <section className="bg-t-o b-r-10 col-12 d-flex align-items-center justify-content-around p-3 flex-column">
                  <section className="row">
                    <section className="col-sm-12 col-md-12">
                      <section className="card custom-card bg-t-o">
                        <section className="card-body bg-t-o">
                          <section>
                            <h2 className="mb-5">First questions</h2>
                            <p className="card-sub-title">
                              Lorem Epsom dummy text with the simplicity of
                              generating name I understand from The printing
                              industry is used by graphic designers
                            </p>
                          </section>
                          <h5>1. How to import all plugins?</h5>
                          <p className="mb-0">
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used Lorem
                            Epsom dummy text with the simplicity of generating
                            name I understand from the printing industry is used
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used
                          </p>
                        </section>
                        <section className="card-body">
                          <h5>2. How can I receive a call?</h5>
                          <p className="mb-0">
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used Lorem
                            Epsom dummy text with the simplicity of generating
                            name I understand from the printing industry is used
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used
                          </p>
                        </section>
                        <section className="card-body">
                          <h5>
                            3. Can I use these plugins in another format use?
                          </h5>
                          <p className="mb-0">
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used Lorem
                            Epsom dummy text with the simplicity of generating
                            name I understand from the printing industry is used
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used
                          </p>
                        </section>
                        <section className="card-body">
                          <h5>
                            4. How can I add another Page in the template?
                          </h5>
                          <p className="mb-0">
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used Lorem
                            Epsom dummy text with the simplicity of generating
                            name I understand from the printing industry is used
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used
                          </p>
                        </section>
                        <section className="card-body">
                          <h5>5. Is it easy to adjust?</h5>
                          <p className="mb-0">
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used Lorem
                            Epsom dummy text with the simplicity of generating
                            name I understand from the printing industry is used
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used
                          </p>
                        </section>
                        <section className="card-body">
                          <h5>6. How can I download this template?</h5>
                          <p className="mb-0">
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used Lorem
                            Epsom dummy text with the simplicity of generating
                            name I understand from the printing industry is used
                            Lorem Epsom dummy text with the simplicity of
                            generating name I understand from the printing
                            industry is used Lorem Epsom dummy text with the
                            simplicity of generating name I understand from the
                            printing industry is used Lorem Epsom dummy text
                            with the simplicity of generating name I understand
                            from the printing industry is used Lorem Epsom dummy
                            text with the simplicity of generating name I
                            understand from the printing industry is used
                          </p>
                        </section>
                      </section>
                    </section>
                  </section>
                </section>
              </section>
            </section>

            <section className="row d-flex align-items-center justify-content-center">
              <section className="d-flex align-items-center justify-content-center p-2">
                <section className="bg-t-o b-r-10 col-12 d-flex align-items-center justify-content-around p-3 flex-column">
                  <span>You still have a question?</span>

                  <span className="pt-3">
                    If you can't find a question in our FAQ, always You can call
                    us. We will reply to you soon Gave!
                  </span>
                </section>
              </section>
            </section>

            <section className="row d-flex align-items-center justify-content-center">
              <section className="d-flex align-items-center justify-content-center p-2">
                <section className="bg-t-o b-r-10 col-12 d-flex align-items-center justify-content-around p-3">
                  <section className="col-5 b-r-5 bg-main p-3 d-flex flex-column align-items-center justify-content-center">
                    <Call />

                    <a
                      target="_blank"
                      href="https://wa.me/c/989039647011"
                      rel="noreferrer"
                      className="text-white pt-3"
                    >
                      my whatsapp
                    </a>

                    <span className="pt-3">
                      The best way to get an answer faster
                    </span>
                  </section>

                  <section className="col-5 b-r-5 bg-main p-3 d-flex flex-column align-items-center justify-content-center">
                    <MailOutline />

                    <a
                      target="_blank"
                      href="https://wa.me/c/989039647011"
                      rel="noreferrer"
                      className="text-white pt-3"
                    >
                      Buy Mistar Panel
                    </a>

                    <span className="pt-3">
                      Give Mistar PanelMessage to buy
                    </span>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
