////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AccountSetting extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <form method="POST" encType="multipart/form-data">
                  <section className="row col-12">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>user name</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="UserName"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                          placeholder="Amir Mohammad"
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>name</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Name"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                          placeholder="Amir Mohammad Koshkian"
                        />
                      </section>
                    </section>
                  </section>
                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>email</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Email"
                          placeholder="email"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Role</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="Role"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="Admin">Manager</option>
                          <option value="Author">Writer</option>
                          <option value="Editor">Editor</option>
                          <option value="Maintainer">keeper</option>
                          <option value="Subscriber">Common</option>
                        </select>
                      </section>
                    </section>
                  </section>
                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Status</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="Status"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="Active">Active</option>
                          <option value="InActive">Inactive</option>
                          <option value="Pending">Expectation</option>
                        </select>
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Company</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Company"
                          type="text"
                          placeholder="Mistar Panel"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Profile picture</span>
                    </section>

                    <section className="col-12">
                      <input
                        type="file"
                        name="ProfileImage"
                        className="input-content-users p-2"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-12 pt-4 d-flex">
                    <section className="col-xl-1 ml-4">
                      <input
                        type="submit"
                        name="SaveChange"
                        value="Save Changes"
                        className="input-content-users p-2 bg-info"
                      />
                    </section>

                    <section className="col-xl-1">
                      <input
                        type="button"
                        name="Cancel"
                        value="reset"
                        className="input-content-users p-2"
                      />
                    </section>
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
