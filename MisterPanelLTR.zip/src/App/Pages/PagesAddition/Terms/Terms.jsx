////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class Slider extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="p-2">
              <section className="col-xl-12 p-2 bg-t-o b-r-10">
                <section className="p-3">
                  <span>regulation Mistar Panel</span>
                </section>

                <section className="col-12">
                  <section className="row">
                    <section className="col-md-12 p-3">
                      <section className="bg-t-o card custom-card">
                        <section className="card-body">
                          <h5>Welcome to Mistar Panel</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, dolore
                            elit, sed do eiusmod tempor incididunt ut labore et
                            magna aliqua. Ut enim ad minim veniam, dolore magna
                            elit, sed do eiusmod tempor incididunt ut labore et
                            aliqua. Ut enim ad minim veniam, dolore magna
                            aliqua. Ut enim ad minim veniam, Lorem ipsum dolor
                            sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, dolore elit, sed do
                            eiusmod tempor incididunt ut labore et magna aliqua.
                            Ut enim ad minim veniam, dolore magna elit, sed do
                            eiusmod tempor incididunt ut labore et aliqua. Ut
                            enim ad minim veniam, dolore magna aliqua. Ut enim
                            ad minim veniam,
                          </p>
                        </section>
                      </section>
                    </section>
                    <section className="col-md-12 p-3">
                      <section className="bg-t-o card custom-card">
                        <section className="card-body">
                          <h5>By using our services</h5>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Ut enim ad minim veniam, dolore
                            elit, sed do eiusmod tempor incididunt ut labore et
                            magna aliqua. Ut enim ad minim veniam, dolore magna
                            elit, sed do eiusmod tempor incididunt ut labore et
                            aliqua. Ut enim ad minim veniam, dolore magna
                            aliqua. Ut enim ad minim veniam, Lorem ipsum dolor
                            sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, dolore elit, sed do
                            eiusmod tempor incididunt ut labore et magna aliqua.
                            Ut enim ad minim veniam, dolore magna elit, sed do
                            eiusmod tempor incididunt ut labore et aliqua. Ut
                            enim ad minim veniam, dolore magna aliqua. Ut enim
                            ad minim veniam,
                          </p>
                        </section>
                      </section>
                    </section>
                    <section className="col-md-12 p-3">
                      <section className="bg-t-o card custom-card">
                        <section className="card-body">
                          <h5>Privacy policy</h5>
                          <p>
                            elit, sed do eiusmod tempor incididunt ut labore et
                            magna aliqua. Ut enim ad minim veniam, dolore magna
                            elit, sed do eiusmod tempor incididunt ut labore et
                            aliqua. Ut enim ad minim veniam, dolore magna
                            aliqua. Ut enim ad minim veniam, Lorem ipsum dolor
                            sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, dolore elit, sed do
                            eiusmod tempor incididunt ut labore et magna aliqua.
                            Ut enim ad minim veniam, dolore magna elit, sed do
                            eiusmod tempor incididunt ut labore et aliqua. Ut
                            enim ad minim veniam, dolore magna aliqua. Ut enim
                            ad minim veniam,
                          </p>
                        </section>
                      </section>
                    </section>
                    <section className="col-md-12 p-3">
                      <section className="bg-t-o card custom-card">
                        <section className="card-body">
                          <h5>copy right</h5>
                          <p>
                            elit, sed do eiusmod tempor incididunt ut labore et
                            magna aliqua. Ut enim ad minim veniam, dolore magna
                            elit, sed do eiusmod tempor incididunt ut labore et
                            aliqua. Ut enim ad minim veniam, dolore magna
                            aliqua. Ut enim ad minim veniam, Lorem ipsum dolor
                            sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, dolore elit, sed do
                            eiusmod tempor incididunt ut labore et magna aliqua.
                            Ut enim ad minim veniam, dolore magna elit, sed do
                            eiusmod tempor incididunt ut labore et aliqua. Ut
                            enim ad minim veniam, dolore magna aliqua. Ut enim
                            ad minim veniam,
                          </p>
                        </section>
                      </section>
                    </section>
                    <section className="col-md-12 p-3">
                      <section className="bg-t-o card custom-card p-3">
                        <section className="card-body">
                          <h5>Terms and Conditions</h5>
                          <p>
                            elit, sed do eiusmod tempor incididunt ut labore et
                            magna aliqua. Ut enim ad minim veniam, dolore magna
                            elit, sed do eiusmod tempor incididunt ut labore et
                            aliqua. Ut enim ad minim veniam, dolore magna
                            aliqua. Ut enim ad minim veniam, Lorem ipsum dolor
                            sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna
                            aliqua. Ut enim ad minim veniam, dolore elit, sed do
                            eiusmod tempor incididunt ut labore et magna aliqua.
                            Ut enim ad minim veniam, dolore magna elit, sed do
                            eiusmod tempor incididunt ut labore et aliqua. Ut
                            enim ad minim veniam, dolore magna aliqua. Ut enim
                            ad minim veniam,
                          </p>
                          <ul className="pr-5">
                            <li>
                              <i className="fa fa-angle-double-right"></i>
                              Lorem Epsom dummy text with the simplicity Lorem
                              Epsom dummy text with the simplicity
                            </li>
                            <li>
                              <i className="fa fa-angle-double-right"></i>
                              Lorem Epsom dummy text with the simplicity Lorem
                              Epsom dummy text with the simplicity
                            </li>
                            <li>
                              <i className="fa fa-angle-double-right"></i>
                              Lorem Epsom dummy text with the simplicity Lorem
                              Epsom dummy text with the simplicity
                            </li>
                            <li>
                              <i className="fa fa-angle-double-right"></i>
                              Lorem Epsom dummy text with the simplicity of
                              generating name I understand from The printing
                              industry is used by graphic designers
                            </li>
                            <li>
                              <i className="fa fa-angle-double-right"></i>
                              Lorem Epsom dummy text with the simplicity of
                              generating name I understand from The printing
                              industry is used by graphic designers
                            </li>
                            <li>
                              <i className="fa fa-angle-double-right"></i>
                              Lorem Epsom dummy text with the simplicity Lorem
                              Epsom dummy text with the simplicity
                            </li>
                          </ul>
                        </section>
                      </section>
                    </section>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
