////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class Tables extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10">
                <section className="col-12 p-3">
                  <span>Table type First</span>
                </section>

                <section className="col-12 p-3">
                  <section className="p-2 table-users-page-new-user-request">
                    <table>
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>user name</th>
                          <th>ID Worker</th>
                          <th>type Plan</th>
                          <th>Expiration date</th>
                          <th>Amount</th>
                          <th>Work type on</th>
                          <th>Edit</th>
                          <th>Delete</th>
                          <th>Preview</th>
                          <th>more information</th>
                          <th>
                            <input
                              type="checkbox"
                              name="check-select-item-user"
                              className="cursor-pointer"
                            />
                          </th>
                        </tr>
                      </thead>

                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <img
                              alt="Profile"
                              lazy="loading"
                              src="/Assets/Images/Profiles/Profile2.png"
                            />
                            <span>Amir Mohammad Koshkian</span>
                          </td>
                          <td>USER126</td>
                          <td>
                            <span className="bg-info b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              Free
                            </span>
                          </td>
                          <td>
                            <span className="bg-info b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              May 21, 1405
                            </span>
                          </td>
                          <td>
                            <span className="bg-warning b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              20$
                            </span>
                          </td>
                          <td>General</td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Edit
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Delete
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              See Preview
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              more information
                            </span>
                          </td>
                          <td>
                            <input
                              type="checkbox"
                              name="check-select-item-user"
                              className="cursor-pointer"
                            />
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-12 p-3">
                  <span>Table type Second</span>
                </section>

                <section className="col-12 p-3">
                  <section className="p-2 table-users-page-seo-settings">
                    <table>
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>query Search</th>
                          <th>Link Search</th>
                          <th>Edit</th>
                          <th>Delete</th>
                        </tr>
                      </thead>

                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Home cleaning services near You</td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              See Preview
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Edit
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Delete
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-12 p-3">
                  <span>Table type Third</span>
                </section>

                <section className="col-12 p-3">
                  <section className="p-2 table-listing-category">
                    <table>
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>category name</th>
                          <th>Category image</th>
                          <th>Create history</th>
                          <th>Contents</th>
                          <th>subcategory</th>
                          <th>Edit</th>
                          <th>View Sub Categories</th>
                          <th>Delete</th>
                        </tr>
                      </thead>

                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <span className="bg-warning b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              Amir Mohammad Koshkian
                            </span>
                          </td>
                          <td>
                            <img
                              alt="Profile"
                              lazy="loading"
                              src="/Assets/Images/Profiles/Profile2.png"
                            />
                          </td>
                          <td>April 3, 2022</td>
                          <td>
                            <span className="bg-info b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              1
                            </span>
                          </td>
                          <td>
                            <span className="bg-info b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              6
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Edit
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              See
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Delete
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-12 p-3">
                  <span>Table type Fourth</span>
                </section>

                <section className="col-12 p-3">
                  <section className="p-2 table-all-expert-lades">
                    <table>
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Worker</th>
                          <th>Details Worker</th>
                          <th>Message</th>
                          <th>Delete</th>
                          <th>Details</th>
                        </tr>
                      </thead>

                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <img
                              alt="Profile"
                              lazy="loading"
                              src="/Assets/Images/Profiles/Profile.png"
                            />
                            <span>Amir Mohammad Koshkian</span>
                          </td>
                          <td className="d-flex flex-column">
                            <span>
                              <span>Phone : </span>0904-545-4545
                            </span>
                            <span>
                              <span>email : </span>koshkian1000@gmail.com
                            </span>
                            <span>
                              <span>Address : </span>Florida Florida
                            </span>
                            <span>
                              <span>History Record name : </span>April 21, 2022
                            </span>
                            <span>
                              <span>History Special membership: </span>May 30,
                              2022
                            </span>
                          </td>
                          <td>Hello to all</td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Delete
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Details
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-12 p-3">
                  <span>Table type Fifth</span>
                </section>

                <section className="col-12 p-3">
                  <section className="p-2 table-all-news">
                    <table>
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>News</th>
                          <th>Grouping</th>
                          <th>published</th>
                          <th>Comment</th>
                          <th>Edit</th>
                          <th>Delete</th>
                          <th>Preview</th>
                          <th>
                            <input
                              type="checkbox"
                              name="check-select-item-user"
                              className="cursor-pointer"
                            />
                          </th>
                        </tr>
                      </thead>

                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            Covid: Face mask rules and covid permit to end at
                            World
                          </td>
                          <td>
                            <span className="bg-info b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              sports
                            </span>
                          </td>
                          <td>12 January 2022</td>
                          <td>
                            <span className="bg-warning b-r-10 pt-1 pb-1 pl-1 pr-1 text-white">
                              46
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Edit
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Delete
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              See Preview
                            </span>
                          </td>
                          <td>
                            <input
                              type="checkbox"
                              name="check-select-item-user"
                              className="cursor-pointer"
                            />
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-12 p-3">
                  <span>Table type Sixth</span>
                </section>

                <section className="col-12 p-3">
                  <section className="p-2 table-ad-pricing">
                    <table>
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>advertisement name</th>
                          <th>Preview ads</th>
                          <th>Ad size</th>
                          <th>Cost / day</th>
                          <th>Status</th>
                          <th>Edit</th>
                        </tr>
                      </thead>

                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Main page down</td>
                          <td>
                            <img
                              alt="Profile"
                              lazy="loading"
                              src="/Assets/Images/Profiles/Profile2.png"
                            />
                          </td>
                          <td>720X90px</td>
                          <td>350$</td>
                          <td>
                            <span className="bg-success b-r-10 pt-1 pb-1 pr-1 pl-1 bg-warning">
                              Active
                            </span>
                          </td>
                          <td>
                            <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                              Edit
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
