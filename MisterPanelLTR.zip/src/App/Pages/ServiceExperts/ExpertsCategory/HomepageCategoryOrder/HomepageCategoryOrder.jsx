////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class HomepageCategoryOrder extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-xl-12 pb-3">
                  <span>Change Search positions</span>
                </section>

                <section className="col-xl-6 p-1">
                  <section className="bg-success p-2">
                    <span className="color-w">
                      Online classes for school students
                    </span>
                  </section>
                </section>
                <section className="col-xl-6 p-1">
                  <section className="bg-warning p-2">
                    <span className="color-w">
                      Home cleaning services near You
                    </span>
                  </section>
                </section>
                <section className="col-xl-6 p-1">
                  <section className="bg-danger p-2">
                    <span className="color-w">
                      The best AC service expert near you
                    </span>
                  </section>
                </section>
                <section className="col-xl-6 p-1">
                  <section className="bg-main p-2">
                    <span className="color-w">Buy iPhone 13 Pro now</span>
                  </section>
                </section>
                <section className="col-xl-6 p-1">
                  <section className="bg-info p-2">
                    <span className="color-w">new Year's celebration</span>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
