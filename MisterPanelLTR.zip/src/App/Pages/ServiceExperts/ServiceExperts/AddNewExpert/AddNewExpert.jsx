////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewExpert extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <form method="POST" encType="multipart/form-data">
                  <section className="col-12">
                    <section className="col-12 p-2">
                      <span>Workbar is selected</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="SelectUser"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="amir mohammad">Amir Mohammad</option>
                        <option value="amir ali">Amir Ali</option>
                        <option value="ali reza">Alireza</option>
                        <option value="mohammad">Mohammad</option>
                        <option value="hossein">Hossein</option>
                      </select>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>City</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="City"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="Florida">Florida</option>
                          <option value="Florida">Florida</option>
                          <option value="Shiraz">California</option>
                          <option value="Florida">Florida</option>
                        </select>
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Work profession</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="WorkProfession"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="ServiceLaptop">Laptop service</option>
                          <option value="ServiceComputer">
                            Computer service
                          </option>
                          <option value="MobileRepairs">Mobile Repairs</option>
                        </select>
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Service start time</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="ServiceStartTime"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="6Morning">6Morning</option>
                          <option value="7Morning">7Morning</option>
                          <option value="8Morning">8Morning</option>
                          <option value="9Morning">9Morning</option>
                          <option value="10Morning">10Morning</option>
                          <option value="11Morning">11Morning</option>
                          <option value="12Morning">12Morning</option>
                          <option value="1Morning">1Morning</option>
                          <option value="2Morning">2Morning</option>
                          <option value="3Morning">3Morning</option>
                          <option value="4Morning">4Morning</option>
                          <option value="5Morning">5Morning</option>
                          <option value="6Morning">6Morning</option>
                          <option value="7Morning">7Morning</option>
                          <option value="8Morning">8Morning</option>
                          <option value="9Morning">9Morning</option>
                          <option value="10Morning">10Morning</option>
                          <option value="11Morning">11Morning</option>
                          <option value="12Morning">12Morning</option>
                        </select>
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>years of experience</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="YearOfExperience"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Service closing time</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="ServiceCloseTime"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="6Morning">6Morning</option>
                          <option value="7Morning">7Morning</option>
                          <option value="8Morning">8Morning</option>
                          <option value="9Morning">9Morning</option>
                          <option value="10Morning">10Morning</option>
                          <option value="11Morning">11Morning</option>
                          <option value="12Morning">12Morning</option>
                          <option value="1Morning">1Morning</option>
                          <option value="2Morning">2Morning</option>
                          <option value="3Morning">3Morning</option>
                          <option value="4Morning">4Morning</option>
                          <option value="5Morning">5Morning</option>
                          <option value="6Morning">6Morning</option>
                          <option value="7Morning">7Morning</option>
                          <option value="8Morning">8Morning</option>
                          <option value="9Morning">9Morning</option>
                          <option value="10Morning">10Morning</option>
                          <option value="11Morning">11Morning</option>
                          <option value="12Morning">12Morning</option>
                        </select>
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Base fare</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="BaseFare"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Profile picture</span>
                      </section>

                      <section className="col-12">
                        <input
                          type="file"
                          name="ProfileImage"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>ProFile cover image</span>
                      </section>

                      <section className="col-12">
                        <input
                          type="file"
                          name="ProfileCoverImage"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Services it can provide</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="ServicesCanDo"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="ServiceLaptop">Laptop service</option>
                        <option value="ServiceComputer">
                          Computer service
                        </option>
                        <option value="MobileRepairs">Mobile Repairs</option>
                      </select>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Service areas</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="ServiceAreas"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="Florida">Florida</option>
                        <option value="Florida">Florida</option>
                        <option value="Shiraz">California</option>
                        <option value="Florida">Florida</option>
                      </select>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Acceptable payment methods</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="PaymentAccept"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="PayPal">PayPal</option>
                        <option value="Payeer">Payer</option>
                        <option value="skrill">Skrill</option>
                      </select>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12">
                      <input
                        type="submit"
                        name="SubmitNewServiceExpert"
                        value="Submit"
                        className="input-content-users p-2 bg-info"
                      />
                    </section>
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
