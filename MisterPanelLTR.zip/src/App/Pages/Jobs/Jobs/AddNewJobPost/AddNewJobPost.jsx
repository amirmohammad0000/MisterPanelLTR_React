////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewJobPost extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <form method="POST" encType="multipart/form-data">
                  <section className="col-12">
                    <section className="col-12 p-2">
                      <span>Workbar is selected</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="SelectUser"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="amir mohammad">Amir Mohammad</option>
                        <option value="amir ali">Amir Ali</option>
                        <option value="ali reza">Alireza</option>
                        <option value="mohammad">Mohammad</option>
                        <option value="hossein">Hossein</option>
                      </select>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>job title</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="JobTitle"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Rights</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Salary"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>History interview</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="InterviewDate"
                          type="text"
                          placeholder="year/month/day"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Interview time</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="InterviewTime"
                          type="text"
                          placeholder="minutes/hours"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Role</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Role"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>education and qualification</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="EducationQualification"
                          type="text"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Location</span>
                      </section>

                      <section className="col-12">
                        <select
                          name="Location"
                          className="input-content-users p-2"
                          required={true}
                        >
                          <option value="German">German</option>
                          <option value="American">America</option>
                          <option value="France">France</option>
                        </select>
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Company logo</span>
                      </section>

                      <section className="col-12">
                        <input
                          type="file"
                          name="Companylogo"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>job category</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="JobCategory"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="ServiceLaptop">Laptop service</option>
                        <option value="ServiceComputer">
                          Computer service
                        </option>
                        <option value="MobileRepairs">Mobile Repairs</option>
                      </select>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>زیر مجموعه مشاغل</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="JobSubCategory"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="ServiceLaptop">Laptop service</option>
                        <option value="ServiceComputer">
                          Computer service
                        </option>
                        <option value="MobileRepairs">Mobile Repairs</option>
                      </select>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Work type</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="JobType"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="Freelancer">Freelancing</option>
                        <option value="Freelancer">Freelancing</option>
                      </select>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>years of experience</span>
                    </section>

                    <section className="col-12">
                      <input
                        type="text"
                        name="YearOfExperience"
                        className="input-content-users p-2"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Your contact number</span>
                    </section>

                    <section className="col-12">
                      <input
                        type="text"
                        name="ContactNumber"
                        className="input-content-users p-2"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>email</span>
                    </section>

                    <section className="col-12">
                      <input
                        type="email"
                        name="Email"
                        className="input-content-users p-2"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>website</span>
                    </section>

                    <section className="col-12">
                      <input
                        type="text"
                        name="Website"
                        className="input-content-users p-2"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Interview location</span>
                    </section>

                    <section className="col-12">
                      <input
                        type="text"
                        name="InterviewLocation"
                        className="input-content-users p-2"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Company name</span>
                    </section>

                    <section className="col-12">
                      <input
                        type="text"
                        name="CompanyName"
                        className="input-content-users p-2"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>job description</span>
                    </section>

                    <section className="col-12">
                      <textarea
                        type="text"
                        name="JobDescriptions"
                        className="input-content-users p-2"
                        required={true}
                      ></textarea>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>About You Company (small details)</span>
                    </section>

                    <section className="col-12">
                      <textarea
                        type="text"
                        name="AboutYourCompany"
                        className="input-content-users p-2"
                        required={true}
                      ></textarea>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12">
                      <input
                        type="submit"
                        name="SubmitAddNewJob"
                        value="Submit"
                        className="input-content-users p-2 bg-info"
                      />
                    </section>
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
