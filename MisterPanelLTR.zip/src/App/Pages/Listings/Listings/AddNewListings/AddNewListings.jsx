////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewListings extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-xl-12 text-center">
                  <span>Add new list</span>
                </section>

                <form method="POST" encType="multipart/form-data">
                  <section className="col-xl-12 pt-4">
                    <select
                      className="input-content-users p-2"
                      name="UserName"
                      required={true}
                    >
                      <option value="UserName">user name</option>
                      <option value="amir mohammad">Amir Mohammad</option>
                      <option value="ali">Ali</option>
                      <option value="mohammad">Mohammad</option>
                      <option value="amir">Amir</option>
                      <option value="hossein">Hossein</option>
                      <option value="amir hossein">Amir Hossein</option>
                      <option value="amir ali">Amir Ali</option>
                    </select>
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      name="ListingName"
                      placeholder="name List"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      name="PhoneNumber"
                      placeholder="Your Phone"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      name="Email"
                      placeholder="email"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      name="WhatsappNumber"
                      placeholder="Your Whatsapp"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      name="website"
                      placeholder="website(https://amirmohammad0.ir)"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      name="ShopAddress"
                      placeholder="Address Store"
                      required={true}
                    />
                  </section>

                  <section className="d-flex col-xl-12 pt-4">
                    <section className="col-xl-6 pl-2">
                      <input
                        type="text"
                        className="input-content-users p-2"
                        name="Latitude"
                        placeholder="Geographical width means 40.730610"
                        required={true}
                      />
                    </section>

                    <section className="col-xl-6 pr-2">
                      <input
                        type="text"
                        className="input-content-users p-2"
                        name="Longitude"
                        placeholder="Geographical height means 73.935242"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="col-xl-12 pt-4">
                    <select
                      className="input-content-users p-2"
                      name="Country"
                      required={true}
                    >
                      <option value="Country">Select Country</option>
                      <option value="America">America</option>
                      <option value="Germany">Germany</option>
                      <option value="Russia">Russia</option>
                      <option value="UnitedKingdom">English</option>
                      <option value="German">Amrican</option>
                    </select>
                  </section>

                  <section className="col-xl-12 pt-4">
                    <select
                      className="input-content-users p-2"
                      name="City"
                      required={true}
                    >
                      <option value="City">Choose your city</option>
                      <option value="Florida">Florida</option>
                      <option value="Florida">Florida</option>
                      <option value="Florida">Florida</option>
                      <option value="Esfahan">Florida</option>
                    </select>
                  </section>

                  <section className="col-xl-12 pt-4">
                    <select
                      className="input-content-users p-2"
                      name="Category"
                      required={true}
                    >
                      <option value="SelectCategory">Select Grouping</option>
                      <option value="Technology">Technology</option>
                      <option value="Sports">sports</option>
                      <option value="Hospital">Hospital</option>
                      <option value="Electrical">electric</option>
                      <option value="Restaurant">Restaurant</option>
                    </select>
                  </section>

                  <section className="col-xl-12 pt-4">
                    <select
                      className="input-content-users p-2"
                      name="SubCategory"
                      required={true}
                    >
                      <option value="SubCategory">Select under Grouping</option>
                      <option value="Technology">Mobile</option>
                      <option value="Sports">Tablet</option>
                      <option value="Electrical">Laptop</option>
                      <option value="Restaurant">Computer</option>
                    </select>
                  </section>

                  <section className="col-xl-12 pt-4">
                    <textarea
                      className="input-content-users p-2"
                      name="DetailsListing"
                      placeholder="Details about Contents You"
                      required={true}
                    ></textarea>
                  </section>

                  <section className="d-flex col-xl-12 pt-4">
                    <section className="col-xl-6 pl-2">
                      <span>Choose a profile picture</span>
                    </section>
                    <section className="col-xl-6 pr-2">
                      <span>Select the cover image</span>
                    </section>
                  </section>
                  <section className="d-flex col-xl-12">
                    <section className="col-xl-6 pl-2">
                      <input
                        type="file"
                        className="input-content-users p-2"
                        name="ProfileImage"
                        placeholder="Choose a profile picture"
                        required={true}
                      />
                    </section>

                    <section className="col-xl-6 pr-2">
                      <input
                        type="file"
                        className="input-content-users p-2"
                        name="CoverImage"
                        placeholder="Select the cover image"
                        required={true}
                      />
                    </section>
                  </section>

                  <section className="d-flex col-xl-12 pt-5">
                    <input
                      type="submit"
                      className="input-content-users p-2 bg-success"
                      name="SubmitListing"
                      value="Submit Contents"
                      required={true}
                    />
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
