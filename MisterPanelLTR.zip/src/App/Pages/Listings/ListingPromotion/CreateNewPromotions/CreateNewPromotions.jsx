////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class CreateNewPromotions extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <section className="col-xl-12">
                  <span>Create Advertising</span>
                </section>

                <form method="POST">
                  <section className="col-xl-12 pt-4">
                    <select
                      className="input-content-users p-2"
                      name="Listing"
                      required={true}
                    >
                      <option value="Listing">Select Contents</option>
                      <option value="amir mohammad">Amir Mohammad</option>
                      <option value="ali">Ali</option>
                      <option value="mohammad">Mohammad</option>
                      <option value="amir">Amir</option>
                      <option value="hossein">Hossein</option>
                      <option value="amir hossein">Amir Hossein</option>
                      <option value="amir ali">Amir Ali</option>
                    </select>
                  </section>

                  <section className="col-xl-12 pt-4">start date</section>
                  <section className="col-xl-12">
                    <input
                      type="text"
                      name="StartDate"
                      placeholder="month/day/year"
                      className="input-content-users p-2"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 pt-4">end date</section>
                  <section className="col-xl-12">
                    <input
                      type="text"
                      name="EndDate"
                      placeholder="month/day/year"
                      className="input-content-users p-2"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 pt-4">
                    <input
                      type="submit"
                      className="input-content-users p-2 bg-success"
                      name="SubmitListing"
                      value="Submit"
                    />
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
