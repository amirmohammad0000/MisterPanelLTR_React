////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AllFeedBacks extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10">
                <section className="d-flex align-items-center justify-content-between p-3">
                  <span>All Feedback Details</span>
                </section>
              </section>
            </section>

            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 pr-2 pl-2">
                <section className="p-2 table-listing-category">
                  <table>
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>name</th>
                        <th>Mobile</th>
                        <th>email</th>
                        <th>Message</th>
                        <th>History</th>
                        <th>Delete</th>
                      </tr>
                    </thead>

                    <tbody>
                      <tr>
                        <td>1</td>
                        <td>
                          <span>Amir Mohammad</span>
                        </td>
                        <td>0903-544-5464</td>
                        <td>koshkain1000@gmail.com</td>
                        <td>Hello</td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            30 January 2022
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Delete
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td>
                          <span>Amir Mohammad</span>
                        </td>
                        <td>0903-656-8585</td>
                        <td>koshkain1000@gmail.com</td>
                        <td>Mistar Panel</td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            30 January 2022
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Delete
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td>
                          <span>Amir Mohammad</span>
                        </td>
                        <td>0903-567-8657</td>
                        <td>koshkain1000@gmail.com</td>
                        <td>admin panel Mistar Panel</td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            30 January 2022
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Delete
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td>
                          <span>Amir Mohammad</span>
                        </td>
                        <td>0903-574-6577</td>
                        <td>koshkain1000@gmail.com</td>
                        <td>I am Amir Mohammad</td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            30 January 2022
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Delete
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td>5</td>
                        <td>
                          <span>Amir Mohammad</span>
                        </td>
                        <td>0903-675-6578</td>
                        <td>koshkain1000@gmail.com</td>
                        <td>Hello I am Amir Mohammad</td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            30 January 2022
                          </span>
                        </td>
                        <td>
                          <span className="input-buttons pt-1 pb-1 pr-1 pl-1">
                            Delete
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
