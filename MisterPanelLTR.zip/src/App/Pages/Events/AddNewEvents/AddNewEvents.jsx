////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewEvents extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10 p-3">
                <form method="POST" encType="multipart/form-data">
                  <section className="col-12">
                    <section className="col-12 p-2">
                      <span>The user chooses is</span>
                    </section>

                    <section className="col-12">
                      <select
                        name="SelectUser"
                        className="input-content-users p-2"
                        required={true}
                      >
                        <option value="amir mohammad">Amir Mohammad</option>
                        <option value="amir ali">Amir Ali</option>
                        <option value="ali reza">Alireza</option>
                        <option value="mohammad">Mohammad</option>
                        <option value="hossein">Hossein</option>
                      </select>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>Event name</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="EventName"
                          type="text"
                          placeholder="Event name"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Address</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Address"
                          type="text"
                          placeholder="Address"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-6 pl-3">
                      <section className="col-12 p-2">
                        <span>History</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Date"
                          placeholder="day/month/year"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>

                    <section className="col-6 pr-3">
                      <section className="col-12 p-2">
                        <span>Time</span>
                      </section>

                      <section className="col-12">
                        <input
                          name="Time"
                          type="text"
                          placeholder="Time"
                          className="input-content-users p-2"
                          required={true}
                        />
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-12">
                      <section className="col-12 p-2">
                        <span>Event details</span>
                      </section>

                      <section className="col-12">
                        <textarea
                          name="EventDetails"
                          placeholder="Event details"
                          className="input-content-users p-2"
                          required={true}
                        ></textarea>
                      </section>
                    </section>
                  </section>

                  <section className="row col-12 pt-4">
                    <section className="col-12">
                      <section className="col-12 p-2">
                        <span>Google map location</span>
                      </section>

                      <section className="col-12">
                        <textarea
                          name="GoogleMapLocation"
                          className="input-content-users p-2"
                          placeholder="Google map location"
                          required={true}
                        ></textarea>
                      </section>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12 p-2">
                      <span>Select the cover image</span>
                    </section>

                    <section className="col-12">
                      <input
                        name="ProductImages"
                        type="file"
                        className="input-content-users p-2"
                        required={true}
                      ></input>
                    </section>
                  </section>

                  <section className="col-12 pt-4">
                    <section className="col-12">
                      <input
                        type="submit"
                        name="SubmitAddNewJob"
                        value="Submit"
                        className="input-content-users p-2 bg-info"
                      />
                    </section>
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
