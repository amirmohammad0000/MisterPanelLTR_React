////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
import {
  KeyboardArrowUp,
  AddShoppingCart,
  Preview,
  TrendingUp,
  TrendingDown,
  AttachMoney,
  Link,
  KeyboardArrowDown,
} from "@mui/icons-material";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Chart from "react-apexcharts";
import { Calendar } from "react-multi-date-picker";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

const SettingsSliderOne = {
  dots: true,
  arrows: false,
  autoplay: true,
  infinite: true,
  speed: 500,
  slidesToShow: 2,
  slidesToScroll: 1,
};

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class Analytics extends React.Component {
  state = {
    SeriesTotalTransactions: [
      {
        name: "Selling to men",
        data: [
          0.4, 0.65, 0.76, 0.88, 1.5, 2.1, 2.9, 3.8, 3.9, 4.2, 4, 4.3, 4.1, 4.2,
          4.5, 3.9, 3.5, 3,
        ],
      },
      {
        name: "Selling to women",
        data: [
          -0.8, -1.05, -1.06, -1.18, -1.4, -2.2, -2.85, -3.7, -3.96, -4.22,
          -4.3, -4.4, -4.1, -4, -4.1, -3.4, -3.1, -2.8,
        ],
      },
    ],
    OptionsTotalTransactions: {
      chart: {
        type: "bar",
        stacked: true,
        toolbar: {
          show: true,
          autoSelected: "pan",
        },
        foreColor: "var(--mp-theme-color)",
      },
      colors: ["#666cff", "#3CCF4E"],
      plotOptions: {
        bar: {
          horizontal: true,
          barHeight: "80%",
          endingShape: "rounded",
        },
      },
      dataLabels: {
        enabled: true,
      },
      stroke: {
        width: 1,
        colors: ["var(--mp-theme-color)"],
      },
      grid: {
        xaxis: {
          lines: {
            show: true,
          },
        },
      },
      yaxis: [
        {
          min: -5,
          max: 5,
        },
      ],
      tooltip: {
        shared: false,
        x: {
          formatter: function (val) {
            return val;
          },
        },
        y: {
          formatter: function (val) {
            return Math.abs(val) + "%";
          },
        },
      },
      xaxis: {
        categories: [
          "85+",
          "80-84",
          "75-79",
          "70-74",
          "65-69",
          "60-64",
          "55-59",
          "50-54",
          "45-49",
          "40-44",
          "35-39",
          "30-34",
          "25-29",
          "20-24",
          "15-19",
          "10-14",
          "5-9",
          "0-4",
        ],
        labels: {
          formatter: function (val) {
            return Math.abs(Math.round(val)) + "%";
          },
        },
      },
    },
    SeriesPerformance: [
      {
        name: "Performance",
        data: [80, 50, 30, 40, 100, 50],
      },
    ],
    OptionsPerformance: {
      chart: {
        type: "radar",
        stacked: true,
        toolbar: {
          show: true,
          autoSelected: "pan",
        },
        foreColor: "var(--mp-theme-color)",
      },
      stroke: {
        width: 1,
        colors: ["var(--mp-theme-color)"],
      },
      colors: ["#3CCF4E"],
      xaxis: {
        categories: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
      },
    },
    SeriesVisit: [
      {
        name: "Regular visitors",
        data: [40, 45, 30, 20, 34, 30, 63, 26, 47],
      },
      {
        name: "Premium visitors",
        data: [60, 35, 60, 69, 65, 30, 20, 34, 53],
      },
      {
        name: "All visitors",
        data: [100, 80, 90, 89, 94, 60, 83, 53, 99],
      },
    ],
    OptionsVisit: {
      chart: {
        type: "bar",
        stacked: true,
        toolbar: {
          show: true,
          autoSelected: "pan",
        },
        foreColor: "var(--mp-theme-color)",
      },
      colors: ["#fb8500", "#666cff", "#3CCF4E"],
      stroke: {
        show: true,
        width: 1,
        colors: ["var(--mp-theme-color)"],
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "60%",
          endingShape: "rounded",
        },
      },
      dataLabels: {
        enabled: true,
      },
      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
        ],
      },
      fill: {
        opacity: 1,
      },
      tooltip: {
        y: {
          formatter: function (value) {
            return value + " Visit";
          },
        },
      },
    },
  };

  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-8 p-2">
              <section className="bg-t-o b-r-10 d-flex align-items-center justify-content-between pr-1 pl-1 pt-1 pb-2">
                <section className="col-sm-6 d-flex align-items-start justify-content-center flex-column p-2">
                  <h1 className="fs-2 p-1">Congratulations Amir Mohammad!</h1>
                  <span>You have sold 89% more today.</span>
                  <span>You have sold 89% more today.</span>
                  <button className="btn btn-success bg-main mt-3">
                    See profile
                  </button>
                </section>

                <section className="col-sm-6 d-flex align-items-end justify-content-center flex-column">
                  <img
                    alt="Logo"
                    loading="lazy"
                    src="/Assets/Images/Logo.png"
                    className="image-logo-content-page-analytics"
                  />
                </section>
              </section>
            </section>

            <section className="col-xl-2 p-2">
              <section className="bg-t-o b-r-10">
                <section className="col-sm-12 d-flex align-items-center justify-content-between p-4">
                  <section>
                    <AddShoppingCart className="text-color-main" />
                  </section>

                  <section>
                    <KeyboardArrowUp className="text-success" />

                    <span className="text-success">30%+</span>
                  </section>
                </section>

                <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-2">
                  <span>155 thousand views</span>
                  <span>Total orders</span>
                </section>

                <section className="col-sm-12 d-flex align-items-start justify-content-start pr-1 pb-3 pt-4">
                  <span className="bg-t-d-m b-r-10 pr-1 pl-1">
                    Last 2 months
                  </span>
                </section>
              </section>
            </section>

            <section className="col-xl-2 p-2">
              <section className="bg-t-o b-r-10">
                <section className="bg-t-o b-r-10">
                  <section className="col-sm-12 d-flex align-items-center justify-content-between p-4">
                    <section>
                      <Preview className="text-color-main" />
                    </section>

                    <section>
                      <KeyboardArrowUp className="text-success" />

                      <span className="text-success">60%+</span>
                    </section>
                  </section>

                  <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-2">
                    <span>100 thousand views</span>
                    <span>Total views</span>
                  </section>

                  <section className="col-sm-12 d-flex align-items-start justify-content-start pr-1 pb-3 pt-4">
                    <span className="bg-t-d-m b-r-10 pr-1 pl-1">
                      Last 5 months
                    </span>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>

        <section className="row">
          <section className="row">
            <section className="col-xl-8 p-2">
              <section className="bg-t-o b-r-10">
                <section className="row p-4">
                  <h3>Visits</h3>
                </section>

                <section className="row h-400 pr-2 pl-2 pb-4">
                  <Chart
                    series={this.state.SeriesVisit}
                    options={this.state.OptionsVisit}
                    width="100%"
                    height="100%"
                    type="bar"
                  />
                </section>
              </section>
            </section>

            <section className="col-xl-4 p-2">
              <section className="bg-t-o b-r-10">
                <section className="row pr-2 p-4">
                  <h3>Performance</h3>
                </section>

                <section className="row h-400 pr-2 pl-2 pb-4">
                  <Chart
                    series={this.state.SeriesPerformance}
                    options={this.state.OptionsPerformance}
                    width="100%"
                    height="100%"
                    type="radar"
                  />
                </section>
              </section>
            </section>
          </section>
        </section>

        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-4 p-2">
              <section className="bg-t-o b-r-10">
                <section className="col-xl-12 p-4 pb-5 pt-3">
                  <section>
                    <h3>visit report</h3>
                    <span>10,000 views last month</span>
                  </section>

                  <section className="row pt-5 pb-4 bb">
                    <section className="col-xl-6 d-flex flex-column align-items-center justify-content-center p-2">
                      <TrendingDown className="bg-danger b-r-10 p-1" />
                      <span className="p-1">This week</span>
                      <span className="p-1">64.35%+</span>
                    </section>

                    <section className="col-xl-6 d-flex flex-column align-items-center justify-content-center brm p-2">
                      <TrendingUp className="bg-success b-r-5 p-1" />
                      <span className="p-1">This week</span>
                      <span className="p-1">56.23%+</span>
                    </section>
                  </section>

                  <section className="row pt-4 pb-4 bb">
                    <section className="col-xl-6 d-flex flex-column align-items-center justify-content-center p-2">
                      <TrendingDown className="bg-danger b-r-10 p-1" />
                      <span className="p-1">this month</span>
                      <span className="p-1">94.23%+</span>
                    </section>

                    <section className="col-xl-6 d-flex flex-column align-items-center justify-content-center brm p-2">
                      <TrendingUp className="bg-success b-r-5 p-1" />
                      <span className="p-1">this month</span>
                      <span className="p-1">63.03%+</span>
                    </section>
                  </section>

                  <section className="row pt-3">
                    <section className="col-xl-6 d-flex flex-column align-items-center justify-content-center p-3">
                      <span className="p-1">Visits</span>
                      <span className="p-1">60.65%+</span>
                    </section>

                    <section className="col-xl-6 d-flex flex-column align-items-center justify-content-center p-3">
                      <button className="btn btn-success bg-main">
                        See visit
                      </button>
                    </section>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-8 p-2">
              <section className="row bg-t-o b-r-10">
                <section className="col-xl-12 pr-4 pt-3 pb-3 pl-3">
                  <section>
                    <h3>Total transactions</h3>
                  </section>

                  <section className="h-500">
                    <Chart
                      series={this.state.SeriesTotalTransactions}
                      options={this.state.OptionsTotalTransactions}
                      width="100%"
                      height="100%"
                      type="bar"
                    />
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>

        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-4 p-2">
              <section className="bg-t-o b-r-10">
                <section className="row pr-2 pt-3">
                  <section className="col-xl-12">
                    <h3>Project statistics</h3>
                  </section>
                </section>

                <section className="row pr-2 pl-2 pt-3">
                  <section className="col-xl-6 d-flex align-items-center justify-content-start">
                    <span>name</span>
                  </section>

                  <section className="col-xl-6 d-flex align-items-center justify-content-end">
                    <span>the budget</span>
                  </section>
                </section>

                <section className="row p-4">
                  <section className="d-flex d-flex align-items-center justify-content-between pb-2">
                    <section className="col-xl-10 d-flex align-items-center justify-content-start">
                      <img
                        alt="Project 1"
                        loading="lazy"
                        src="/Assets/Images/Project/Project1.png"
                        width="50px"
                        className="col-xl-1"
                      />

                      <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                        <span>Illustration of three Next</span>

                        <span>Blender app</span>
                      </section>
                    </section>

                    <section className="col-xl-2 d-flex align-center justify-content-center">
                      <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                        100$
                      </span>
                    </section>
                  </section>

                  <section className="d-flex d-flex align-items-center justify-content-between pb-2 pt-2">
                    <section className="col-xl-10 d-flex align-items-center justify-content-start">
                      <img
                        alt="Project 2"
                        loading="lazy"
                        src="/Assets/Images/Project/Project2.png"
                        width="50px"
                        className="col-xl-1"
                      />

                      <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                        <span>Financial application design</span>

                        <span>Figma ui kit</span>
                      </section>
                    </section>

                    <section className="col-xl-2 d-flex align-center justify-content-center">
                      <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                        150$
                      </span>
                    </section>
                  </section>

                  <section className="d-flex d-flex align-items-center justify-content-between pb-2 pt-2">
                    <section className="col-xl-10 d-flex align-items-center justify-content-start">
                      <img
                        alt="Project 3"
                        loading="lazy"
                        src="/Assets/Images/Project/Project3.png"
                        width="50px"
                        className="col-xl-1"
                      />

                      <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                        <span>Whatsapp</span>

                        <span>Android app</span>
                      </section>
                    </section>

                    <section className="col-xl-2 d-flex align-center justify-content-center">
                      <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                        200$
                      </span>
                    </section>
                  </section>

                  <section className="d-flex d-flex align-items-center justify-content-between pb-2 pt-2">
                    <section className="col-xl-10 d-flex align-items-center justify-content-start">
                      <img
                        alt="Project 4"
                        loading="lazy"
                        src="/Assets/Images/Project/Project4.png"
                        width="50px"
                        className="col-xl-1"
                      />

                      <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                        <span>Web application</span>

                        <span>React</span>
                      </section>
                    </section>

                    <section className="col-xl-2 d-flex align-center justify-content-center">
                      <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                        160$
                      </span>
                    </section>
                  </section>

                  <section className="d-flex d-flex align-items-center justify-content-between pt-2">
                    <section className="col-xl-10 d-flex align-items-center justify-content-start">
                      <img
                        alt="Project 5"
                        loading="lazy"
                        src="/Assets/Images/Project/Project5.png"
                        width="50px"
                        className="col-xl-1"
                      />

                      <section className="col-xl-11 pr-2 d-flex flex-column align-center justify-content-start">
                        <span>website</span>

                        <span>Vue + Laravel</span>
                      </section>
                    </section>

                    <section className="col-xl-2 d-flex align-center justify-content-center">
                      <span className="bg-t-d-m b-r-10 pr-1 pl-1 text-nowrap">
                        120$
                      </span>
                    </section>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-4 row">
              <section className="col-xl-6">
                <section className="col-xl-12 p-2 mb-1">
                  <section className="bg-t-o b-r-10">
                    <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                      <section>
                        <AttachMoney className="text-color-main" />
                      </section>

                      <section>
                        <KeyboardArrowUp className="text-success" />

                        <span className="text-success">75.2K</span>
                      </section>
                    </section>

                    <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-1 pl-1 pb-2">
                      <span>Total income</span>
                    </section>

                    <section className="col-sm-12 pr-1 pl-1 pb-3 pt-4 pb-4">
                      <section className="d-flex align-items-start justify-content-between">
                        <span>Percentage of income</span>
                        <span>75</span>
                      </section>
                      <section className="progress">
                        <section
                          aria-valuemax="100"
                          aria-valuemin="0"
                          aria-valuenow="20"
                          className="progress-bar progress-bar-xs wd-75p"
                          role="progressbar"
                        ></section>
                      </section>
                    </section>
                  </section>
                </section>

                <section className="col-xl-12 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                      <section>
                        <Link className="text-color-main" />
                      </section>

                      <section>
                        <KeyboardArrowUp className="text-success" />

                        <span className="text-success">64.4%+</span>
                      </section>
                    </section>

                    <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-2">
                      <span className="pb-1">142.8 Thousand</span>
                      <span>Total withdrawals</span>
                    </section>

                    <section className="col-sm-12 d-flex align-items-start justify-content-start pr-1 pb-3 pt-4">
                      <span className="bg-t-d-m b-r-10 pr-1 pl-1">
                        A year past
                      </span>
                    </section>
                  </section>
                </section>
              </section>

              <section className="col-xl-6">
                <section className="col-xl-12 p-2 mb-1">
                  <section className="bg-t-o b-r-10">
                    <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                      <section>
                        <Link className="text-color-main" />
                      </section>

                      <section>
                        <KeyboardArrowUp className="text-success" />

                        <span className="text-success">83.4%+</span>
                      </section>
                    </section>

                    <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-2">
                      <span className="pb-1">54.8 Thousand</span>
                      <span>Total withdrawals</span>
                    </section>

                    <section className="col-sm-12 d-flex align-items-start justify-content-start pr-1 pb-3 pt-4">
                      <span className="bg-t-d-m b-r-10 pr-1 pl-1">
                        last two years
                      </span>
                    </section>
                  </section>
                </section>

                <section className="col-xl-12 p-2">
                  <section className="bg-t-o b-r-10">
                    <section className="col-sm-12 d-flex align-items-center justify-content-between pr-1 pl-1 pt-4 pb-5">
                      <section>
                        <AttachMoney className="text-color-main" />
                      </section>

                      <section>
                        <KeyboardArrowUp className="text-success" />

                        <span className="text-success">6.2K</span>
                      </section>
                    </section>

                    <section className="col-sm-12 d-flex align-items-start justify-content-center flex-column pr-1 pl-1 pb-2">
                      <span>Total income</span>
                    </section>

                    <section className="col-sm-12 pr-1 pl-1 pb-3 pt-4 pb-4">
                      <section className="d-flex align-items-start justify-content-between">
                        <span>Percentage of income</span>
                        <span>45</span>
                      </section>
                      <section className="progress">
                        <section
                          aria-valuemax="100"
                          aria-valuemin="0"
                          aria-valuenow="20"
                          className="progress-bar progress-bar-xs bg-danger wd-45p"
                          role="progressbar"
                        ></section>
                      </section>
                    </section>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-4 p-2">
              <section className="bg-t-o b-r-10">
                <section className="bg-t-o b-r-10">
                  <section className="row pr-2 pb-4 pt-3">
                    <h3>Most purchases in countries</h3>
                  </section>

                  <section className="row d-flex pr-2 pb-2 flex-column">
                    <section className="d-flex align-items-start justify-content-start">
                      <h2 className="m-0 pl-3">222,546</h2>
                      <span className="bg-success b-r-10 p-1">54.7%+</span>
                    </section>
                    <span className="pt-2">Sales of the last 90 days</span>
                  </section>

                  <section className="row bt pt-3 pb-3 mr-4 ml-4">
                    <section className="col-6">
                      <span>Russia</span>
                    </section>
                    <section className="col-4">
                      <span>8,635</span>
                    </section>
                    <section className="col-2">
                      <span className="pl-1">43%</span>
                      <KeyboardArrowUp className="text-success" />
                    </section>
                  </section>

                  <section className="row bt pt-3 pb-3 mr-4 ml-4">
                    <section className="col-6">
                      <span>France</span>
                    </section>
                    <section className="col-4">
                      <span>12,656</span>
                    </section>
                    <section className="col-2">
                      <span className="pl-1">75%</span>
                      <KeyboardArrowUp className="text-success" />
                    </section>
                  </section>

                  <section className="row bt pt-3 pb-3 mr-4 ml-4">
                    <section className="col-6">
                      <span>India</span>
                    </section>
                    <section className="col-4">
                      <span>34,272</span>
                    </section>
                    <section className="col-2">
                      <span className="pl-1">34%</span>
                      <KeyboardArrowDown className="text-danger" />
                    </section>
                  </section>

                  <section className="row bt pt-3 pb-3 mr-4 ml-4">
                    <section className="col-6">
                      <span>Germany</span>
                    </section>
                    <section className="col-4">
                      <span>8,934</span>
                    </section>
                    <section className="col-2">
                      <span className="pl-1">45%</span>
                      <KeyboardArrowUp className="text-success" />
                    </section>
                  </section>

                  <section className="row bt pt-3 pb-3 mr-4 ml-4">
                    <section className="col-6">
                      <span>Amrican</span>
                    </section>
                    <section className="col-4">
                      <span>5,573</span>
                    </section>
                    <section className="col-2">
                      <span className="pl-1">46%</span>
                      <KeyboardArrowDown className="text-danger" />
                    </section>
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>

        <section className="row">
          <section className="row">
            <section className="col-xl-8 p-2">
              <section className="bg-t-o b-r-10">
                <section className="row p-4 pb-5">
                  <h3>Activity timeline</h3>
                </section>

                <section className="row pb-4 d-flex align-items-center justify-content-between">
                  <section className="col-9 position-relative">
                    <span className="span-point-right-activity-time-line-content-page-analytics bg-danger"></span>

                    <section className="d-flex flex-column pr-5">
                      <p>Make a video for Next product</p>

                      <span>Introduction video and product details</span>
                    </section>
                  </section>

                  <section className="col-3 d-flex align-items-center justify-content-center">
                    <span>Tomorrow</span>
                  </section>
                </section>

                <section className="row pb-4 d-flex align-items-center justify-content-between">
                  <section className="col-9 position-relative">
                    <span className="span-point-right-activity-time-line-content-page-analytics bg-primary"></span>

                    <section className="d-flex flex-column pr-5">
                      <p>A payment has been received from the customer</p>

                      <span>Received $100,000 for Android Banking App</span>
                    </section>
                  </section>

                  <section className="col-3 d-flex align-items-center justify-content-center">
                    <span>April 12</span>
                  </section>
                </section>

                <section className="row pb-4 d-flex align-items-center justify-content-between">
                  <section className="col-9 position-relative">
                    <span className="span-point-right-activity-time-line-content-page-analytics bg-success"></span>

                    <section className="d-flex flex-column pr-5">
                      <p>
                        Meeting with Amir Mohammad Koshkian for the Next project
                      </p>

                      <span>Video call session at 9 pm</span>
                    </section>
                  </section>

                  <section className="col-3 d-flex align-items-center justify-content-center">
                    <span>May 21</span>
                  </section>
                </section>
              </section>
            </section>

            <section className="col-xl-4 p-2">
              <section className="bg-t-o b-r-10">
                <section className="row pr-2 pb-4 pt-3">
                  <h3>Most sold in countries</h3>
                </section>

                <section className="row d-flex pr-2 pb-3 flex-column">
                  <section className="d-flex align-items-start justify-content-start">
                    <h2 className="m-0 pl-3">222,546</h2>

                    <span className="bg-success b-r-10 p-1">42.5%+</span>
                  </section>

                  <span className="pt-2">Sales of the last 90 days</span>
                </section>

                <section className="row bt pt-2 pb-2 mr-4 ml-4">
                  <section className="col-6">
                    <span>Australia</span>
                  </section>

                  <section className="col-4">
                    <span>10,357</span>
                  </section>

                  <section className="col-2">
                    <span className="pl-1">85%</span>

                    <KeyboardArrowUp className="text-success" />
                  </section>
                </section>

                <section className="row bt pt-2 pb-2 mr-4 ml-4">
                  <section className="col-6">
                    <span>Canada</span>
                  </section>

                  <section className="col-4">
                    <span>16,937</span>
                  </section>

                  <section className="col-2">
                    <span className="pl-1">54%</span>

                    <KeyboardArrowDown className="text-danger" />
                  </section>
                </section>

                <section className="row bt pt-2 pb-2 mr-4 ml-4">
                  <section className="col-6">
                    <span>India</span>
                  </section>

                  <section className="col-4">
                    <span>43,473</span>
                  </section>

                  <section className="col-2">
                    <span className="pl-1">76%</span>

                    <KeyboardArrowUp className="text-success" />
                  </section>
                </section>

                <section className="row bt pt-2 pb-2 mr-4 ml-4">
                  <section className="col-6">
                    <span>Japan</span>
                  </section>

                  <section className="col-4">
                    <span>19,757</span>
                  </section>

                  <section className="col-2">
                    <span className="pl-1">42%</span>

                    <KeyboardArrowUp className="text-success" />
                  </section>
                </section>

                <section className="row bt pt-2 pb-2 mr-4 ml-4">
                  <section className="col-6">
                    <span>United States</span>
                  </section>

                  <section className="col-4">
                    <span>12,565</span>
                  </section>

                  <section className="col-2">
                    <span className="pl-1">84%</span>

                    <KeyboardArrowDown className="text-danger" />
                  </section>
                </section>
              </section>
            </section>
          </section>
        </section>

        <section className="row">
          <section className="row">
            <section className="col-xl-3 p-2">
              <section className="bg-t-o b-r-10">
                <section className="h-400 p-3">
                  <Calendar className="w-100 h-100 d-flex align-items-center justify-content-center" />
                </section>
              </section>
            </section>

            <section className="col-xl-9 p-2">
              <section className="bg-t-o b-r-10">
                <section className="p-3 h-400">
                  <Slider {...SettingsSliderOne} className="slider-three">
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider1.png"
                      />
                    </section>
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider2.png"
                      />
                    </section>
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider3.png"
                      />
                    </section>
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider4.png"
                      />
                    </section>
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider5.png"
                      />
                    </section>
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider6.png"
                      />
                    </section>
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider7.png"
                      />
                    </section>
                    <section className="section-image-slider-page-analytics">
                      <img
                        alt="ImageSlider"
                        loading="lazy"
                        src="/Assets/Images/Slider/Slider8.png"
                      />
                    </section>
                  </Slider>
                </section>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
