////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewPage extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <form method="POST">
                <section className="bg-t-o b-r-10">
                  <section className="col-xl-12 p-3">
                    <span>Add New Page</span>
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="name Page"
                      name="PageName"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-xl-12 p-3">
                    <span>Contents to display this Page Selection is:</span>
                  </section>

                  <section className="col-xl-12 p-3">
                    <select
                      className="input-content-users p-2"
                      name="SelectOption"
                    >
                      <option>test 1</option>
                      <option>test 2</option>
                      <option>test 3</option>
                      <option>test 4</option>
                      <option>test 5</option>
                    </select>
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-xl-12 p-3">
                    <span>SEO settings</span>
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Title Page"
                      name="PageTitle"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Page keywords"
                      name="PageKeywords"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Description Page"
                      name="PageDescriptions"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-xl-12 p-3">
                    <span>SEO settings before gone</span>
                  </section>

                  <section className="col-xl-12 p-3">
                    <textarea
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Google schema"
                      name="GoogleSchema"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-xl-12 p-3">
                    <span>release</span>
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="submit"
                      className="input-content-users p-2 bg-success"
                      name="SaveChange"
                      value="Submit"
                    />
                  </section>
                </section>
              </form>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
