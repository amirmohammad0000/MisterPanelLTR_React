////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class AddNewPage extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <form method="POST" encType="multipart/form-data">
                <section className="bg-t-o b-r-10">
                  <section className="col-xl-12 p-3">
                    <span>Added a new page for the e-book</span>
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Title banner"
                      name="BannerTitle"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="sub Title banner"
                      name="BannerSubTitle"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Link Download"
                      name="DownloadLink"
                      required={true}
                    />
                  </section>

                  <section className="col-xl-12 p-3">
                    <input
                      className="input-content-users p-2"
                      required={true}
                      type="file"
                      name="EbookPreviewImage"
                    />
                  </section>

                  <section className="col-12 p-3">
                    <textarea
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Details about List You"
                      name="PageDescriptions"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-12 p-3">
                    <span>Custom CSS styles</span>
                  </section>

                  <section className="col-12 p-3">
                    <textarea
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Write your CSS styles here"
                      name="CustomCSSStyles"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-12 p-3">
                    <span>Js custom script</span>
                  </section>

                  <section className="col-12 p-3">
                    <textarea
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Write your Java Script codes here"
                      name="CustomJsScript"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-12 p-3">
                    <span>SEO settings</span>
                  </section>

                  <section className="col-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Title Page"
                      name="PageTitle"
                      required={true}
                    />
                  </section>

                  <section className="col-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Page keywords"
                      name="PageKeywords"
                      required={true}
                    />
                  </section>

                  <section className="col-12 p-3">
                    <input
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Description Page"
                      name="PageDescriptions"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-12 p-3">
                    <span>SEO settings before gone</span>
                  </section>

                  <section className="col-12 p-3">
                    <textarea
                      type="text"
                      className="input-content-users p-2"
                      placeholder="Google schema"
                      name="GoogleSchema"
                      required={true}
                    />
                  </section>
                </section>

                <section className="bg-t-o b-r-10">
                  <section className="col-12 p-3">
                    <span>release</span>
                  </section>

                  <section className="row d-flex col-12 p-3">
                    <span className="col-xl-2">Status</span>

                    <section className="col-xl-10">
                      <select className="input-content-users p-2" name="Status">
                        <option value="Public">release</option>
                        <option value="Draft">Draft</option>
                      </select>
                    </section>
                  </section>

                  <section className="row d-flex col-12 p-3">
                    <span className="col-xl-2">See</span>

                    <section className="col-xl-10">
                      <select
                        className="input-content-users p-2"
                        name="Visibility"
                      >
                        <option value="Public">release</option>
                        <option value="Private">private</option>
                      </select>
                    </section>
                  </section>

                  <section className="col-12 p-3">
                    <input
                      type="submit"
                      className="input-content-users p-2 bg-success"
                      name="SaveChange"
                      value="Submit"
                    />
                  </section>
                </section>
              </form>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
