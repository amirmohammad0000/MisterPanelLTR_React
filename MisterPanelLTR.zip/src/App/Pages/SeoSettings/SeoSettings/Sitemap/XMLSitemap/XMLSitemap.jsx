////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Imports
import React from "react";
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Imports

////////////////////////////////////////////////////////////////////////////////////////////////////// Start Section Class
export default class XMLSitemap extends React.Component {
  render() {
    return (
      <section className="p-3">
        <section className="row">
          <section className="row d-flex align-items-center justify-content-center">
            <section className="col-xl-12 p-2">
              <section className="bg-t-o b-r-10">
                <section className="col-12 p-3 text-center">
                  <span>XML site role</span>
                </section>

                <form
                  className="col-12 p-3 text-center"
                  method="POST"
                  encType="multipart/form-data"
                >
                  <span>
                    To create a role for your site{" "}
                    <a
                      href="https://www.xml-sitemaps.com/"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Here
                    </a>{" "}
                    Click is, then upload is in the box below.
                  </span>

                  <section className="pt-5 d-flex align-items-center justify-content-center flex-column">
                    <section className="col-md-6 pb-4">upload File XML</section>

                    <section className="col-12 p-3">
                      <input
                        className="input-content-users p-2"
                        required={true}
                        type="file"
                        name="XMLFile"
                      />
                    </section>
                  </section>

                  <section className="col-12 p-3">
                    <input
                      type="submit"
                      className="input-content-users p-2 bg-success"
                      name="SendXMLSitemap"
                      value="Submit"
                    />
                  </section>
                </form>
              </section>
            </section>
          </section>
        </section>
      </section>
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////// End Section Class
